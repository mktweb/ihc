<html>
<body>
    <form action="login.php" method="post" name="formLogin">
    Username:
    <input type="text" name="username"/>
    <br/>
    Password:
    <input type="password" name="password"/>
    <br/>
    <input type="submit" name="sendButton" value="Login"/>
    </form>
</body>
</html>
